<!-- Header start -->
<header id="header" class="header-one">
  <div class="bg-white">
    <div class="container">
      <div class="logo-area">
          <div class="row align-items-center">
            <div class="logo col-lg-3 text-center text-lg-left mb-4 mb-md-5 mb-lg-0">
                <a class="d-block" href="/">
                  <img loading="lazy" src="<?=base_url()?>assets/template/images/logo_put3.png" alt="PUT_SP">
                </a>
            </div><!-- logo end -->
  
            <div class="col-lg-9 header-right">
                <ul class="top-info-box">
                  <li>
                    <div class="info-box">
                      <div class="info-box-content">
                          <p class="info-box-title">Whatsapp Us</p>
                          <p class="info-box-subtitle"><a href="https://wa.me/6282196601441" target="blank">(+62) 821-9660-1441</a></p>
                      </div>
                    </div>
                  </li>
                  <li>
                    <div class="info-box">
                      <div class="info-box-content">
                          <p class="info-box-title">Email Us</p>
                          <p class="info-box-subtitle"><a href="mailto:teknologigeomatika@gmail.com">teknologigeomatika@gmail.com</a></p>
                      </div>
                    </div>
                  </li>
                  <!-- <li class="last">
                    <div class="info-box last">
                      <div class="info-box-content">
                          <p class="info-box-title">Global Certificate</p>
                          <p class="info-box-subtitle">ISO 0000:0000</p>
                      </div>
                    </div>
                  </li> -->
                  <!-- <li class="header-get-a-quote">
                    <a class="btn btn-primary" href="<?=base_url()?>permohonan/ajukan">Permohonan</a>
                  </li> -->
                </ul><!-- Ul end -->
            </div><!-- header right end -->
          </div><!-- logo area end -->
  
      </div><!-- Row end -->
    </div><!-- Container end -->
  </div>