<section id="main-container" class="main-container">
  <div class="container">
  <div class="row">
  <div class="col-md-12">
    <?php
      if ($noreg == '') {
        echo form_open_multipart('permohonan/status1') ?>
          <div class="row">
            <div class="col-md-4">
              <div class="form-group">
                <label>Kode Registrasi :</label>
                <input class="form-control form-control-name" name="noreg" id="noreg" placeholder="Masukkan Kode Registrasi" type="text" required>
              </div>
              <div class="text-right"><br>
                <button class="btn btn-primary solid blank" type="submit"><i class="fa fa-paper-plane fa-fw"></i> Cek Status</button>
              </div>
            </div>
          </div>
        <?php echo form_close();

      } else { ?>
        Noreg = <?= $noreg ?>
        Nama = <?= $confirm->nama ?>

      <?php
      }
    ?>
  </div>
  </div>
  </div>
</section>